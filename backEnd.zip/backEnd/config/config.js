module.exports = {
    port: 3000 || process.env.PORT,
    "database": "mongodb://localhost:27017/myDB"
}